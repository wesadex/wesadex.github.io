﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

    /**
     * SMOOTH SECONDS SCRIPTS
     */
     let now;
     let lastTime = 0;
     let animTimer;
     let widgetDelegate;
     const animDuration = 5000;
     const animFps = 25; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion
 
     function setSec() {
       const screenType = hmSetting.getScreenType();
       if (screenType === hmSetting.screen_type.AOD) {
         return stopSecAnim();
       }
       if (!now) {
         now = hmSensor.createSensor(hmSensor.id.TIME);
       }
       if (widgetDelegate) return;
 
       widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
         resume_call: (function () {
           console.log('ui resume');
 
           if (animTimer) return;
 
           let duration = 0;
           const diffTime = now.utc - lastTime;
           if (diffTime < animDuration) {
             duration = animDuration - diffTime;
           }
 
           animTimer = timer.createTimer(duration, animDuration, (function (option) {
             lastTime = now.utc;
             startSecAnim(now.second * 6);
           }));
         }),
         pause_call: (function () {
           console.log('ui pause');
           stopSecAnim();
         }),
       });
     }
 
     function startSecAnim(sec) {
       const secAnim = {
         anim_rate: 'linear',
         anim_duration: animDuration,
         anim_from: sec,
         anim_to: sec + animDuration * 6 / 1000,
         repeat_count: 1,
         anim_fps: animFps,
         anim_key: "angle",
         anim_status: 1,
       }
 
       normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
     }
 
     /**
      * onDestroy()
      */
     function stopSecAnim() {
       if (animTimer) {
         timer.stopTimer(animTimer);
         animTimer = undefined;
       }
     }
 
     /** END SMOOTH SECOND SCRIPTS */

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'Bezel_1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'Bezel_2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'Bezel_3.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'Bezel_4.png' },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_bg: 'shortcut_pointer.png',
              tips_x: 100,
              tips_y: 100,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 413,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 164,
              y: 412,
              src: 'st_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 354,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: 0,
              negative_image: 'minus.png',
              invalid_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 354,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: 0,
              negative_image: 'minus.png',
              invalid_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 364,
              font_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              padding: false,
              h_space: 0,
              negative_image: '55.png',
              invalid_image: '55.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 177,
              y: 357,
              image_array: ["0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 384,
              y: 168,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 438,
              y: 174,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 353,
              y: 268,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: 0,
              dot_image: 'd01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 268,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 42,
              y: 168,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 26,
              y: 174,
              image_array: ["stat_1.png","stat_2.png","stat_3.png","stat_4.png","stat_5.png","stat_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 302,
              month_startY: 120,
              month_sc_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              month_tc_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              month_en_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 233,
              day_startY: 120,
              day_sc_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              day_tc_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              day_en_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '57.png',
              day_unit_tc: '57.png',
              day_unit_en: '57.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 120,
              week_en: ["4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              week_tc: ["4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              week_sc: ["4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 29,
              hour_posY: 223,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 30,
              minute_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = normal_analog_clock_time_pointer_second || hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              pos_x: 480 / 2 - 35,
              pos_y: 480 / 2 - 224,
              center_x: 240,
              center_y: 240,
              src: "3.png",
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            setSec();
 
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 29,
              hour_posY: 223,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 30,
              minute_posY: 225,
              show_level: hmUI.show_level.ONLY_AOD,
            });

           // idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
           //   second_path: '3.png',
           //   second_centerX: 240,
           //   second_centerY: 240,
           //   second_posX: 35,
           //   second_posY: 224,
           //   show_level: hmUI.show_level.ONLY_AOD,
           // });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 4,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 338,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 140,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 353,
              y: 240,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
                stopSecAnim();
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
